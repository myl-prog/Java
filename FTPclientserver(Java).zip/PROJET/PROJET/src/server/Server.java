package server;
/*
 * TP JAVA RIP
 * Min Serveur FTP
 * */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class Server {
	public static String currentDir=null;
	public static void main(String[] args) throws Exception {
		System.out.println("Le Serveur FTP est en marche !");

		 
		
		
		try(ServerSocket serveurFTP = new ServerSocket(2022)){
	         while (true) {
	        	 System.out.println("Serveur en attente des Clients ...");
	             new ClientThread(serveurFTP.accept()).run();
	         }
		}
		
		 

		

	}
	
	
	public static class ClientThread implements Runnable {

		private Socket socket;

		public ClientThread(Socket socket) {
			this.socket = socket;
		}

		@Override
		public void run() {

			BufferedReader br = null;
			PrintStream ps = null;
			try {
				br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				ps = new PrintStream(socket.getOutputStream());

				ps.println("1 Bienvenue ! ");
				ps.println("1 Serveur FTP Personnel.");
				ps.println("0 Authentification : ");

				String commande = "";
				// Attente de reception de commandes et leur execution

				while ((commande = br.readLine()) != null) {
					
					if (commande.equals("bye")) {
						ps.println("0 Merci et Aurevoir.");
						System.out.println("Merci et Aurevoir");
						
						//On met les pwOk et userOk sur false pour bien effectu� la deconnexion
						
						CommandExecutor.pwOk=false;
						CommandExecutor.userOk=false;
						break;
					} else
						CommandExecutor.executeCommande(socket, commande);
				}
				
			} catch (IOException e) {
				System.out.println("Client deconnecte.");
				
				//On met les pwOk et userOk sur false pour bien effectu� la deconnexion
				
				CommandExecutor.pwOk=false;
				CommandExecutor.userOk=false;

			} finally {
				try {
					
					socket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

			}

		}

	}

}

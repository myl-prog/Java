package server;
import java.io.File;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;

public class CommandePWD extends Commande {
	
	public CommandePWD(Socket clientSocket, String commandeStr) {
		super(clientSocket, commandeStr);
	}

	

	public void execute() {
		//On stock le chemin actuel dans la variable Server.currentDir
		
		if(Server.currentDir == null) {
			File file = new File(".");
			String s = "Path: ";
			s =s+ file.getAbsoluteFile().toString();
			Server.currentDir=s;
			ps.println("0 " + s);
			
		}else {
			ps.println("0 " + Server.currentDir);
			
		}
		
	}

}



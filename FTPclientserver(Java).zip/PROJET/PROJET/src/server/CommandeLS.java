package server;
import java.io.File;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.*;

public class CommandeLS extends Commande {
	
	public CommandeLS(Socket clientSocket, String commandeStr) {
		super( clientSocket, commandeStr);
	}

	public void execute() {
		/*
		*/
		File file = new File(".");
		//si Server.currentDir est existant 
		if(Server.currentDir !=null) {
			//On enleve le "Path" dan la chaine currentDir avec un split
			file = new File(Server.currentDir.split(" ")[1]);
		}
			// On cr�e un tableau de fichier pour parcourir chaque fichier dans le repertoire courant
			File[] files = file.listFiles();
			//Une chaine de caracteres qu'on remplira au fur et a mesure de chaque nom de fichier
			String filesList="";
	        
		    if (files != null)
		    for (int i = 0; i < files.length; i++) {
		        
		        File f = files[i];
		        if (f.isDirectory() || f.isFile()) {   
		             
		        	filesList=filesList+ "    " +f.getName();
		        }
		    }
			ps.println("0 " + filesList );
		
		
	}
	
	
}

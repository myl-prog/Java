package server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;

public abstract class Commande {

	protected Socket clientSocket;
	protected PrintStream ps;
	protected InputStream ins;
	protected OutputStream outs;

	protected String commandeNom = "";
	protected String[] commandeArgs;
	public static String user = "";

	public Commande(Socket clientSocket, String commandeStr) {

		try {
			this.clientSocket = clientSocket;
			
			this.ps = new PrintStream(clientSocket.getOutputStream());
			System.out.println(clientSocket.getOutputStream());
			this.ins = clientSocket.getInputStream();
			this.outs = clientSocket.getOutputStream();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String[] args = commandeStr.split(" ");
		commandeNom = args[0];
		commandeArgs = new String[args.length - 1];

		for (int i = 0; i < commandeArgs.length; i++) {

			commandeArgs[i] = args[i + 1];
		}
	}

	public abstract void execute();

}
